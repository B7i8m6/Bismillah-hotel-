# Bismillah Hotel website + Android app starter

## Included
- Responsive restaurant website
- Menu categories and prices supplied for Bismillah Hotel
- Cart and WhatsApp order message to +91 7411171175
- Contact links for 7411171175 and 9902028146
- Opening hours, address and Google Maps directions
- PWA manifest and service worker (installable from a supported browser)
- Admin panel to turn dishes ON/OFF and change prices

## Important limitations before public launch
1. The admin panel currently stores settings in the browser's local storage. It is a prototype and changes only appear in that browser/device. For a real restaurant launch where customers on other phones see changes immediately, connect a shared backend (for example Firebase or Supabase) and secure admin authentication.
2. Starter admin PIN is `2468`. Change `ADMIN_PIN` in `index.html` before using it. This PIN is client-side and is not secure enough for a public production admin panel.
3. Confirm the lunch opening time. This project uses **12:30 PM–3:00 PM**, interpreting the earlier message “noon 12 30am” as 12:30 PM.
4. The menu currently places Kabab and Leg Piece in a separate category using the weekday prices supplied. Confirm if they should be available every day.
5. Prices are shown as provided. Verify all prices, spelling and availability before publishing.

## Test locally
Open `index.html` in a browser. WhatsApp ordering and the map link require internet access.
For PWA installation, host the files over HTTPS (GitHub Pages is one free option), then open the site in Chrome on Android and choose **Install app** or **Add to Home screen**.

## Free website hosting
You can publish the static site using GitHub Pages:
1. Create/sign in to a GitHub account.
2. Create a public repository, e.g. `bismillah-hotel`.
3. Upload `index.html`, `manifest.json`, `sw.js`, and `icon.svg` to the repository root.
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. GitHub Pages will show the public website URL after deployment.

## Android app
This project is a Progressive Web App (PWA), which can be installed on Android from the published HTTPS website. That provides an app-like icon and standalone launch.
A separately packaged APK requires Android build tooling and signing. The included `capacitor.config.json` is a starting point for a Capacitor wrapper, but an APK still needs to be built and tested using Android Studio or a supported cloud build service.

## Capacitor starter
- Run `npm install`
- Run `npm install @capacitor/core @capacitor/cli @capacitor/android`
- Run `npx cap add android`
- Run `npx cap sync android`
- Open the Android project in Android Studio and build a signed APK.
